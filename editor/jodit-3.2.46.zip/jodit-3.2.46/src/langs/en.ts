import { IDictionary } from '../types';

export default {
	'Type something': 'Start writing...',
	pencil: 'Edit',
} as IDictionary<string>;
